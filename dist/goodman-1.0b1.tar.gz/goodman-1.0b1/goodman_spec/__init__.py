"""Goodman Spectroscopic Tools

"""

from redspec import MainApp
