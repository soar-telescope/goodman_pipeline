from ccdproc import CCDData
from goodman_ccd.core import identify_targets, trace_targets
import glob
import astropy.units as u

files = glob.glob('/user/simon/data/soar/tests/target_detection/RED/cfzsto_SNR*fits')
# files = glob.glob('/user/simon/data/soar/work/aller/2017-06-09/RED/cfzsto_*fits')

for ff in files:
    print('Processing File: {:s}'.format(ff))
    ccd = CCDData.read(ff, unit=u.adu)
    ccd.header['OFNAME'] = ff.split('/')[-1]
    ids = identify_targets(ccd=ccd, nfind=1, plots=False)
    print(ids)
    tr = trace_targets(ccd=ccd, profile=ids)
    print(tr)
