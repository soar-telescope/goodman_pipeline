from __future__ import absolute_import

from ..wcs import WCS


def test_wcs_read():
    wcs_instance = WCS()
    assert 1 == 1


def test_wcs_fit():
    wcs_instance = WCS()
    assert 1 == 1
