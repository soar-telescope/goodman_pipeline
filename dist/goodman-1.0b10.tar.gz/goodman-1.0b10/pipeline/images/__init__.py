"""Goodman CCD Reduction Tool

"""

from .goodman_ccd import MainApp, get_args
from .image_processor import ImageProcessor
