from __future__ import absolute_import


from ..night_organizer import NightOrganizer


def test_night_organizer_spectroscopy_night():
    pass


def test_night_organizer_imaging_night():
    pass
