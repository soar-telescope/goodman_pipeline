from __future__ import absolute_import


from ..image_processor import ImageProcessor


def test_define_trim_section():
    pass


def test_get_overscan_region():
    pass


def test_create_master_bias():
    pass


def test_create_master_flats():
    pass


def test_name_master_flats():
    pass


def test_process_spectroscopy_science():
    pass


def test_processing_imaging_science():
    pass


def test_combine_data():
    pass
