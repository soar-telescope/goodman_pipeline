from __future__ import absolute_import


from ..goodman_ccd import get_args, MainApp


def test_get_args():
    pass


def test_main_app():
    pass