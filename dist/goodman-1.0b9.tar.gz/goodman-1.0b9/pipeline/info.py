from __future__ import absolute_import

__version__ = '1.0b9'
__author__ = 'Simon Torres'
__date__ = '2016-06-28'
__email__ = "storres@ctio.noao.edu"
__status__ = "Development"
