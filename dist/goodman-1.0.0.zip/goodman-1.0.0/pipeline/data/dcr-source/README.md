# dcr
This repository is a copy of DCR by Wojtek Pych.

The Original Software can be found in http://users.camk.edu.pl/pych/DCR/

## Wojtek Contact Information
- E-mail: pych@camk.edu.pl
- Phone: +48 22 32 96 107 

# Cite
If you used DCR either the original or this modified version you have to Cite.
`Pych, W., 2004, PASP, 116, 148`
