Goodman Spectroscopic Reduction Pipeline
========================================

This pipeline has been developed to work on the SOAR Data Reduction Servers
so, installation will not be officially supported by the development team.
However you are welcome to install it on your own machine and we have
tried our best to provide you extensive and clear documentation and in
particular, installation instructions for the most common platforms. (except
Windows of course).

Included in this package is a version of the user_manual.pdf file. Which
includes all the instruction needed.

If you think some part is not covered in the user manual, please contact
storres [at] ctio noao edu
