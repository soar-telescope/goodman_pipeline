"""CCD Reduction Tool"""

from goodman_ccdreduction import Main