from __future__ import absolute_import

__version__ = '1.0.0'
__author__ = 'Simon Torres, Bruno Quint, Cesar Briceño'
__date__ = '2018-04-30'
__email__ = "goodman-pipeline@ctio.noao.edu"
__status__ = "rtw"
